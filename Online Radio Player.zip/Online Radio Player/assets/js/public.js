(function($) {
    'use strict';

    $(document).ready(function() {
        // Handle all radio players on the page
        $('.online-radio-player').each(function() {
            var playerId = $(this).data('channel-id');
            var playerType = $(this).data('player-type');
            initRadioPlayer(playerId, playerType);
        });
        
        // Add extra animation to live badges
        animateLiveBadges();
    });

    function initRadioPlayer(channelId, playerType) {
        // Player elements for this specific channel
        var audioPlayer = document.getElementById('radio-audio-player-' + channelId);
        var hlsPlayer = document.getElementById('radio-hls-player-' + channelId);
        var playPauseButton = document.getElementById('play-pause-button-' + channelId);
        var playIcon = playPauseButton.querySelector('.play-icon');
        var pauseIcon = playPauseButton.querySelector('.pause-icon');
        var muteButton = document.getElementById('mute-button-' + channelId);
        var volumeIcon = muteButton.querySelector('.volume-icon');
        var muteIcon = muteButton.querySelector('.mute-icon');
        var volumeSlider = document.getElementById('volume-slider-' + channelId);

        // Add loading indicator
        var loadingIndicator = document.createElement('span');
        loadingIndicator.className = 'loading-indicator';
        loadingIndicator.innerHTML = '●●●';
        loadingIndicator.style.display = 'none';
        loadingIndicator.style.marginLeft = '10px';
        loadingIndicator.style.fontSize = '12px';
        playPauseButton.parentNode.appendChild(loadingIndicator);

        // Debug information
        console.log('Initializing radio player for channel ' + channelId + ' with type: ' + playerType);
        var source = audioPlayer ? audioPlayer.querySelector('source') : null;
        if (source) {
            var streamUrl = source.src;
            console.log('Stream URL: ' + streamUrl);
            console.log('Stream type: ' + source.type);
        }

        // Play/Pause functionality
        playPauseButton.addEventListener('click', function() {
            // Pause all other players
            $('.radio-audio-player').not('#radio-audio-player-' + channelId).each(function() {
                this.pause();
                var otherChannelId = $(this).data('channel');
                var otherPlayIcon = document.querySelector('#play-pause-button-' + otherChannelId + ' .play-icon');
                var otherPauseIcon = document.querySelector('#play-pause-button-' + otherChannelId + ' .pause-icon');
                if (otherPlayIcon && otherPauseIcon) {
                    otherPlayIcon.style.display = 'inline';
                    otherPauseIcon.style.display = 'none';
                }
            });
            
            // Also pause HLS players
            $('.radio-hls-player').not('#radio-hls-player-' + channelId).each(function() {
                if (this.hls) {
                    this.hls.stopLoad();
                    this.hls.destroy();
                }
                this.pause();
            });
            
            if ((audioPlayer && audioPlayer.paused) || (hlsPlayer && hlsPlayer.paused)) {
                // Show loading indicator
                loadingIndicator.style.display = 'inline';
                playIcon.style.display = 'none';
                pauseIcon.style.display = 'none';
                
                // Handle different player types
                if (playerType === 'hls' && hlsPlayer) {
                    playHLSStream(hlsPlayer, channelId, playIcon, pauseIcon, loadingIndicator);
                } else if (audioPlayer) {
                    playAudioStream(audioPlayer, channelId, playIcon, pauseIcon, loadingIndicator);
                }
            } else {
                if (audioPlayer) {
                    audioPlayer.pause();
                }
                if (hlsPlayer) {
                    if (hlsPlayer.hls) {
                        hlsPlayer.hls.stopLoad();
                        hlsPlayer.hls.destroy();
                    }
                    hlsPlayer.pause();
                }
                loadingIndicator.style.display = 'none';
                playIcon.style.display = 'inline';
                pauseIcon.style.display = 'none';
            }
        });

        // Mute functionality
        muteButton.addEventListener('click', function() {
            if (audioPlayer) {
                audioPlayer.muted = !audioPlayer.muted;
            }
            if (hlsPlayer) {
                hlsPlayer.muted = !hlsPlayer.muted;
            }
            if (audioPlayer && audioPlayer.muted || hlsPlayer && hlsPlayer.muted) {
                volumeIcon.style.display = 'none';
                muteIcon.style.display = 'inline';
            } else {
                volumeIcon.style.display = 'inline';
                muteIcon.style.display = 'none';
            }
        });

        // Volume control
        volumeSlider.addEventListener('input', function() {
            var volume = parseFloat(this.value);
            if (audioPlayer) {
                audioPlayer.volume = volume;
            }
            if (hlsPlayer) {
                hlsPlayer.volume = volume;
            }
            
            // Update volume slider background for visual feedback
            var val = volume * 100;
            this.style.background = '-webkit-linear-gradient(left ,#ffffff 0%,#ffffff ' + val + '%,#9e9e9e ' + val + '%, #9e9e9e 100%)';
            
            if (volume == 0) {
                if (audioPlayer) audioPlayer.muted = true;
                if (hlsPlayer) hlsPlayer.muted = true;
                volumeIcon.style.display = 'none';
                muteIcon.style.display = 'inline';
            } else if ((audioPlayer && audioPlayer.muted) || (hlsPlayer && hlsPlayer.muted)) {
                if (audioPlayer) audioPlayer.muted = false;
                if (hlsPlayer) hlsPlayer.muted = false;
                volumeIcon.style.display = 'inline';
                muteIcon.style.display = 'none';
            }
        });

        // Handle audio errors
        if (audioPlayer) {
            audioPlayer.addEventListener('error', function(e) {
                console.error('Audio playback error for channel ' + channelId + ':', e);
                loadingIndicator.style.display = 'none';
                playIcon.style.display = 'inline';
                pauseIcon.style.display = 'none';
                
                // Show detailed error to user
                var errorMessage = 'Failed to load the radio stream. ';
                if (e.target.error) {
                    switch (e.target.error.code) {
                        case e.target.error.MEDIA_ERR_ABORTED:
                            errorMessage += 'The fetching process was aborted by the user.';
                            break;
                        case e.target.error.MEDIA_ERR_NETWORK:
                            errorMessage += 'A network error occurred.';
                            break;
                        case e.target.error.MEDIA_ERR_DECODE:
                            errorMessage += 'The audio failed to decode.';
                            break;
                        case e.target.error.MEDIA_ERR_SRC_NOT_SUPPORTED:
                            errorMessage += 'The audio format is not supported. ';
                            // Try alternative formats
                            tryAlternativeFormats(audioPlayer, channelId, playIcon, pauseIcon, loadingIndicator);
                            break;
                        default:
                            errorMessage += 'An unknown error occurred.';
                            break;
                    }
                } else {
                    errorMessage += 'An unknown error occurred.';
                }
                console.error(errorMessage);
                
                // Try to get more specific error information
                if (e.target.error && e.target.error.message) {
                    console.error('Detailed error message: ' + e.target.error.message);
                }
            });
        }
        
        // Handle HLS player errors
        if (hlsPlayer) {
            hlsPlayer.addEventListener('error', function(e) {
                console.error('HLS playback error for channel ' + channelId + ':', e);
                loadingIndicator.style.display = 'none';
                playIcon.style.display = 'inline';
                pauseIcon.style.display = 'none';
                
                // Try alternative formats for HLS streams
                tryAlternativeFormats(hlsPlayer, channelId, playIcon, pauseIcon, loadingIndicator, true);
            });
        }
        
        // Handle various audio events
        if (audioPlayer) {
            // Handle audio stalled
            audioPlayer.addEventListener('stalled', function(e) {
                console.warn('Audio streaming stalled for channel ' + channelId);
            });
            
            // Handle audio waiting
            audioPlayer.addEventListener('waiting', function(e) {
                console.warn('Audio is waiting for data for channel ' + channelId);
            });
            
            // Handle audio playing
            audioPlayer.addEventListener('playing', function() {
                console.log('Audio is now playing for channel ' + channelId);
                loadingIndicator.style.display = 'none';
                playIcon.style.display = 'none';
                pauseIcon.style.display = 'inline';
                
                // Add playing class to live badge when audio is playing
                var liveBadge = document.querySelector('.online-radio-player[data-channel-id="' + channelId + '"] .radio-live-badge');
                if (liveBadge) {
                    liveBadge.classList.add('live-badge-playing');
                }
            });
            
            // Handle audio canplay
            audioPlayer.addEventListener('canplay', function() {
                console.log('Audio can play for channel ' + channelId);
            });
            
            // Handle audio canplaythrough
            audioPlayer.addEventListener('canplaythrough', function() {
                console.log('Audio can play through without buffering for channel ' + channelId);
            });
            
            // Handle audio loadstart
            audioPlayer.addEventListener('loadstart', function() {
                console.log('Audio load started for channel ' + channelId);
            });
            
            // Handle audio loadeddata
            audioPlayer.addEventListener('loadeddata', function() {
                console.log('Audio data loaded for channel ' + channelId);
            });
            
            // Handle audio loadedmetadata
            audioPlayer.addEventListener('loadedmetadata', function() {
                console.log('Audio metadata loaded for channel ' + channelId);
            });
            
            // Handle audio ended (rare for live streams)
            audioPlayer.addEventListener('ended', function() {
                playIcon.style.display = 'inline';
                pauseIcon.style.display = 'none';
                
                // Remove playing class from live badge when audio ends
                var liveBadge = document.querySelector('.online-radio-player[data-channel-id="' + channelId + '"] .radio-live-badge');
                if (liveBadge) {
                    liveBadge.classList.remove('live-badge-playing');
                }
            });
            
            // Handle audio pause
            audioPlayer.addEventListener('pause', function() {
                console.log('Audio paused for channel ' + channelId);
                playIcon.style.display = 'inline';
                pauseIcon.style.display = 'none';
                
                // Remove playing class from live badge when audio is paused
                var liveBadge = document.querySelector('.online-radio-player[data-channel-id="' + channelId + '"] .radio-live-badge');
                if (liveBadge) {
                    liveBadge.classList.remove('live-badge-playing');
                }
            });
        }
    }

    function playAudioStream(audioPlayer, channelId, playIcon, pauseIcon, loadingIndicator) {
        // Get the source URL
        var source = audioPlayer.querySelector('source');
        if (!source) {
            console.error('No source found for audio player ' + channelId);
            loadingIndicator.style.display = 'none';
            playIcon.style.display = 'inline';
            pauseIcon.style.display = 'none';
            return;
        }
        
        var streamUrl = source.src;
        console.log('Playing audio stream: ' + streamUrl);
        
        // Special handling for URLs containing 'vobook' (cross-origin)
        if (streamUrl.includes('vobook')) {
            audioPlayer.crossOrigin = 'anonymous';
            console.log('Setting crossOrigin for vobook URL');
        }
        
        // Check if it's an HLS stream (even if not detected as such)
        if (streamUrl.includes('.m3u8') && typeof Hls !== 'undefined' && Hls.isSupported()) {
            console.log('Detected HLS stream, using hls.js for channel ' + channelId);
            
            // Create a new audio element for HLS
            var hlsAudio = new Audio();
            hlsAudio.crossOrigin = 'anonymous';
            
            var hls = new Hls({
                enableWorker: true,
                lowLatencyMode: true,
                backBufferLength: 90
            });
            
            hls.loadSource(streamUrl);
            hls.attachMedia(hlsAudio);
            
            hls.on(Hls.Events.MANIFEST_PARSED, function() {
                console.log('HLS manifest parsed for channel ' + channelId);
                hlsAudio.play().then(function() {
                    loadingIndicator.style.display = 'none';
                    playIcon.style.display = 'none';
                    pauseIcon.style.display = 'inline';
                    console.log('HLS playback started successfully for channel ' + channelId);
                }).catch(function(error) {
                    console.error('HLS playback failed for channel ' + channelId + ':', error);
                    loadingIndicator.style.display = 'none';
                    playIcon.style.display = 'inline';
                    pauseIcon.style.display = 'none';
                    // Try alternative formats
                    tryAlternativeFormats(audioPlayer, channelId, playIcon, pauseIcon, loadingIndicator);
                });
            });
            
            hls.on(Hls.Events.ERROR, function(event, data) {
                console.error('HLS error for channel ' + channelId + ':', data);
                if (data.fatal) {
                    switch(data.type) {
                        case Hls.ErrorTypes.NETWORK_ERROR:
                            console.log('Trying to recover network error for channel ' + channelId);
                            hls.startLoad();
                            break;
                        case Hls.ErrorTypes.MEDIA_ERROR:
                            console.log('Trying to recover media error for channel ' + channelId);
                            hls.recoverMediaError();
                            break;
                        default:
                            console.error('Fatal HLS error for channel ' + channelId);
                            hls.destroy();
                            loadingIndicator.style.display = 'none';
                            playIcon.style.display = 'inline';
                            pauseIcon.style.display = 'none';
                            // Try alternative formats
                            tryAlternativeFormats(audioPlayer, channelId, playIcon, pauseIcon, loadingIndicator);
                            break;
                    }
                }
            });
            
            // Store reference to hls object for cleanup
            audioPlayer.hls = hls;
            return;
        }
        
        // For regular streams, including audio/mpeg, reset and play
        var src = streamUrl;
        // Add timestamp to prevent caching issues
        var separator = src.indexOf('?') !== -1 ? '&' : '?';
        src = src + separator + '_t=' + new Date().getTime();
        
        // Set the MIME type explicitly for MP3 streams
        source.type = 'audio/mpeg';
        
        source.src = '';
        audioPlayer.load();
        source.src = src;
        audioPlayer.load();
        
        // Try to play the stream
        var playPromise = audioPlayer.play();
        
        if (playPromise !== undefined) {
            playPromise.then(function() {
                // Playback started successfully
                loadingIndicator.style.display = 'none';
                playIcon.style.display = 'none';
                pauseIcon.style.display = 'inline';
                console.log('Playback started successfully for channel ' + channelId);
            }).catch(function(error) {
                console.error('Playback failed for channel ' + channelId + ':', error);
                loadingIndicator.style.display = 'none';
                playIcon.style.display = 'inline';
                pauseIcon.style.display = 'none';
                
                // Show specific error message based on error type
                var errorMessage = 'Failed to play the radio stream. ';
                if (error.name === 'NotAllowedError') {
                    errorMessage += 'Please interact with the page first (click somewhere) and try again.';
                } else if (error.name === 'NotSupportedError') {
                    errorMessage += 'The audio format is not supported by your browser. ';
                    // Try alternative formats
                    tryAlternativeFormats(audioPlayer, channelId, playIcon, pauseIcon, loadingIndicator);
                } else if (error.name === 'AbortError') {
                    errorMessage += 'The playback was aborted.';
                } else if (error.message) {
                    errorMessage += error.message;
                } else {
                    errorMessage += 'Please check the stream URL or try again later.';
                }
                
                // Show error to user
                alert(errorMessage);
            });
        } else {
            // Fallback for older browsers
            try {
                audioPlayer.play();
                loadingIndicator.style.display = 'none';
                playIcon.style.display = 'none';
                pauseIcon.style.display = 'inline';
            } catch (error) {
                console.error('Playback failed for channel ' + channelId + ':', error);
                loadingIndicator.style.display = 'none';
                playIcon.style.display = 'inline';
                pauseIcon.style.display = 'none';
                // Try alternative formats
                tryAlternativeFormats(audioPlayer, channelId, playIcon, pauseIcon, loadingIndicator);
            }
        }
    }

    function playHLSStream(hlsPlayer, channelId, playIcon, pauseIcon, loadingIndicator) {
        // Check if hls.js is available
        if (typeof Hls !== 'undefined' && Hls.isSupported()) {
            var streamUrl = hlsPlayer.getAttribute('data-stream-url');
            
            // Special handling for URLs containing 'vobook' (cross-origin)
            if (streamUrl.includes('vobook')) {
                hlsPlayer.crossOrigin = 'anonymous';
                console.log('Setting crossOrigin for vobook URL in HLS player');
            }
            
            if (!hlsPlayer.hls) {
                hlsPlayer.hls = new Hls({
                    enableWorker: true,
                    lowLatencyMode: true,
                    backBufferLength: 90
                });
                hlsPlayer.hls.loadSource(streamUrl);
                hlsPlayer.hls.attachMedia(hlsPlayer);
            }
            
            hlsPlayer.hls.on(Hls.Events.MANIFEST_PARSED, function() {
                console.log('HLS manifest parsed for channel ' + channelId);
                hlsPlayer.play().then(function() {
                    loadingIndicator.style.display = 'none';
                    playIcon.style.display = 'none';
                    pauseIcon.style.display = 'inline';
                    console.log('HLS playback started successfully for channel ' + channelId);
                }).catch(function(error) {
                    console.error('HLS playback failed for channel ' + channelId + ':', error);
                    loadingIndicator.style.display = 'none';
                    playIcon.style.display = 'inline';
                    pauseIcon.style.display = 'none';
                    // Try alternative formats
                    tryAlternativeFormats(hlsPlayer, channelId, playIcon, pauseIcon, loadingIndicator, true);
                });
            });
            
            hlsPlayer.hls.on(Hls.Events.ERROR, function(event, data) {
                console.error('HLS error for channel ' + channelId + ':', data);
                if (data.fatal) {
                    switch(data.type) {
                        case Hls.ErrorTypes.NETWORK_ERROR:
                            // Try to recover network error
                            console.log('Trying to recover network error for channel ' + channelId);
                            hlsPlayer.hls.startLoad();
                            break;
                        case Hls.ErrorTypes.MEDIA_ERROR:
                            console.log('Trying to recover media error for channel ' + channelId);
                            hlsPlayer.hls.recoverMediaError();
                            break;
                        default:
                            // Cannot recover
                            console.error('Fatal HLS error for channel ' + channelId);
                            hlsPlayer.hls.destroy();
                            loadingIndicator.style.display = 'none';
                            playIcon.style.display = 'inline';
                            pauseIcon.style.display = 'none';
                            // Try alternative formats
                            tryAlternativeFormats(hlsPlayer, channelId, playIcon, pauseIcon, loadingIndicator, true);
                            break;
                    }
                }
            });
        } else if (hlsPlayer.canPlayType('application/vnd.apple.mpegurl')) {
            // Native HLS support (Safari)
            hlsPlayer.src = hlsPlayer.getAttribute('data-stream-url');
            
            // Special handling for URLs containing 'vobook' (cross-origin)
            if (hlsPlayer.src.includes('vobook')) {
                hlsPlayer.crossOrigin = 'anonymous';
                console.log('Setting crossOrigin for vobook URL in native HLS player');
            }
            
            hlsPlayer.addEventListener('loadedmetadata', function() {
                hlsPlayer.play().then(function() {
                    loadingIndicator.style.display = 'none';
                    playIcon.style.display = 'none';
                    pauseIcon.style.display = 'inline';
                    console.log('Native HLS playback started successfully for channel ' + channelId);
                }).catch(function(error) {
                    console.error('Native HLS playback failed for channel ' + channelId + ':', error);
                    loadingIndicator.style.display = 'none';
                    playIcon.style.display = 'inline';
                    pauseIcon.style.display = 'none';
                    // Try alternative formats
                    tryAlternativeFormats(hlsPlayer, channelId, playIcon, pauseIcon, loadingIndicator, true);
                });
            });
        } else {
            // No HLS support - fallback to regular audio
            console.log('HLS not supported, falling back to regular audio for channel ' + channelId);
            var fallbackAudio = document.getElementById('radio-audio-player-' + channelId);
            if (fallbackAudio) {
                playAudioStream(fallbackAudio, channelId, playIcon, pauseIcon, loadingIndicator);
            } else {
                console.error('HLS not supported and no fallback audio player found for channel ' + channelId);
                loadingIndicator.style.display = 'none';
                playIcon.style.display = 'inline';
                pauseIcon.style.display = 'none';
                // Try alternative formats
                tryAlternativeFormats(hlsPlayer, channelId, playIcon, pauseIcon, loadingIndicator, true);
            }
        }
    }
    
    function tryAlternativeFormats(playerElement, channelId, playIcon, pauseIcon, loadingIndicator, isHLS = false) {
        console.log('Trying alternative formats for channel ' + channelId);
        
        // Get the original stream URL
        var originalUrl = '';
        if (isHLS) {
            originalUrl = playerElement.getAttribute('data-stream-url');
        } else {
            var source = playerElement.querySelector('source');
            if (source) {
                originalUrl = source.src;
            }
        }
        
        if (!originalUrl) {
            console.error('No original URL found for channel ' + channelId);
            alert('Failed to play the radio stream. Please check the stream URL.');
            return;
        }
        
        // Extract base URL without extension or query parameters
        var baseUrl = originalUrl.split('?')[0];
        var baseUrlWithoutExt = baseUrl;
        
        // Remove common extensions
        var extensions = ['.m3u8', '.mp3', '.aac', '.ogg', '.wav', '.flac', '.pls', '.xspf'];
        for (var i = 0; i < extensions.length; i++) {
            if (baseUrlWithoutExt.endsWith(extensions[i])) {
                baseUrlWithoutExt = baseUrlWithoutExt.substring(0, baseUrlWithoutExt.length - extensions[i].length);
                break;
            }
        }
        
        // List of alternative formats to try
        var alternativeFormats = [
            { ext: '.mp3', mime: 'audio/mpeg' },
            { ext: '.aac', mime: 'audio/aac' },
            { ext: '.ogg', mime: 'audio/ogg' },
            { ext: '.wav', mime: 'audio/wav' },
            { ext: '.flac', mime: 'audio/flac' }
        ];
        
        // Try each alternative format
        var tryNextFormat = function(index) {
            if (index >= alternativeFormats.length) {
                // No more formats to try
                console.error('All alternative formats failed for channel ' + channelId);
                loadingIndicator.style.display = 'none';
                playIcon.style.display = 'inline';
                pauseIcon.style.display = 'none';
                alert('Failed to play the radio stream with all attempted formats. Please check the stream URL or try again later.');
                return;
            }
            
            var format = alternativeFormats[index];
            var newUrl = baseUrlWithoutExt + format.ext;
            
            // If the new URL is the same as the original, skip it
            if (newUrl === baseUrl) {
                tryNextFormat(index + 1);
                return;
            }
            
            console.log('Trying alternative format: ' + newUrl);
            
            // Show loading indicator
            loadingIndicator.style.display = 'inline';
            playIcon.style.display = 'none';
            pauseIcon.style.display = 'none';
            
            // Try to play with the new format
            if (isHLS) {
                // For HLS, we're switching to regular audio
                var audioPlayer = document.getElementById('radio-audio-player-' + channelId);
                if (audioPlayer) {
                    var source = audioPlayer.querySelector('source');
                    if (source) {
                        source.src = newUrl;
                        source.type = format.mime;
                        audioPlayer.load();
                        
                        var playPromise = audioPlayer.play();
                        if (playPromise !== undefined) {
                            playPromise.then(function() {
                                // Success
                                loadingIndicator.style.display = 'none';
                                playIcon.style.display = 'none';
                                pauseIcon.style.display = 'inline';
                                console.log('Alternative format playback started successfully: ' + newUrl);
                            }).catch(function(error) {
                                console.error('Alternative format playback failed: ' + newUrl, error);
                                tryNextFormat(index + 1);
                            });
                        } else {
                            // Fallback for older browsers
                            try {
                                audioPlayer.play();
                                loadingIndicator.style.display = 'none';
                                playIcon.style.display = 'none';
                                pauseIcon.style.display = 'inline';
                                console.log('Alternative format playback started successfully: ' + newUrl);
                            } catch (error) {
                                console.error('Alternative format playback failed: ' + newUrl, error);
                                tryNextFormat(index + 1);
                            }
                        }
                    } else {
                        tryNextFormat(index + 1);
                    }
                } else {
                    tryNextFormat(index + 1);
                }
            } else {
                // For regular audio, try the new format
                var source = playerElement.querySelector('source');
                if (source) {
                    source.src = newUrl;
                    source.type = format.mime;
                    playerElement.load();
                    
                    var playPromise = playerElement.play();
                    if (playPromise !== undefined) {
                        playPromise.then(function() {
                            // Success
                            loadingIndicator.style.display = 'none';
                            playIcon.style.display = 'none';
                            pauseIcon.style.display = 'inline';
                            console.log('Alternative format playback started successfully: ' + newUrl);
                        }).catch(function(error) {
                            console.error('Alternative format playback failed: ' + newUrl, error);
                            tryNextFormat(index + 1);
                        });
                    } else {
                        // Fallback for older browsers
                        try {
                            playerElement.play();
                            loadingIndicator.style.display = 'none';
                            playIcon.style.display = 'none';
                            pauseIcon.style.display = 'inline';
                            console.log('Alternative format playback started successfully: ' + newUrl);
                        } catch (error) {
                            console.error('Alternative format playback failed: ' + newUrl, error);
                            tryNextFormat(index + 1);
                        }
                    }
                } else {
                    tryNextFormat(index + 1);
                }
            }
        };
        
        // Start trying alternative formats
        tryNextFormat(0);
    }
    
    function openInBrowserPlayer(streamUrl) {
        console.log('Attempting to open stream in browser player: ' + streamUrl);
        
        // Create a temporary link to open the stream
        var link = document.createElement('a');
        link.href = streamUrl;
        link.target = '_blank';
        link.style.display = 'none';
        
        // Add to DOM, click, and remove
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    function animateLiveBadges() {
        // Add extra animation to live badges
        var liveBadges = document.querySelectorAll('.radio-live-badge');
        liveBadges.forEach(function(badge, index) {
            // Add a slight delay to each badge animation for a staggered effect
            badge.style.animationDelay = (index * 0.2) + 's';
        });
    }

})(jQuery);