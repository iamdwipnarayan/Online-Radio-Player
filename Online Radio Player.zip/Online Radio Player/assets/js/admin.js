(function($) {
    'use strict';

    $(document).ready(function() {
        // Upload logo button
        $('#upload_logo_button').on('click', function(e) {
            e.preventDefault();

            // Create the media frame
            var file_frame = wp.media.frames.file_frame = wp.media({
                title: 'Select or Upload Logo',
                button: {
                    text: 'Use this logo'
                },
                multiple: false
            });

            // When an image is selected, run a callback
            file_frame.on('select', function() {
                var attachment = file_frame.state().get('selection').first().toJSON();
                
                $('#radio_channel_logo').val(attachment.id);
                $('#radio-channel-logo-container img').remove();
                $('#radio-channel-logo-container').prepend('<img src="' + attachment.url + '" alt="Channel Logo" style="max-width: 100%; height: auto;" />');
                $('#remove_logo_button').show();
            });

            // Finally, open the modal
            file_frame.open();
        });

        // Remove logo button
        $('#remove_logo_button').on('click', function(e) {
            e.preventDefault();
            $('#radio_channel_logo').val('');
            $('#radio-channel-logo-container img').remove();
            $(this).hide();
        });

        // Show/hide remove button based on logo existence
        if (!$('#radio_channel_logo').val()) {
            $('#remove_logo_button').hide();
        }
        
        // Add some helpful tips
        $('#radio_stream_url').after('<p class="description">Tip: Test your stream URL in a browser or media player before using it here.</p>');
    });

})(jQuery);