<?php

/**
 * The admin-specific functionality of the plugin.
 */

class Online_Radio_Player_Admin {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of this plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Register the stylesheets for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        wp_enqueue_style($this->plugin_name, ONLINE_RADIO_PLAYER_URL . 'assets/css/admin.css', array(), $this->version, 'all');
    }

    /**
     * Register the JavaScript for the admin area.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        wp_enqueue_script($this->plugin_name, ONLINE_RADIO_PLAYER_URL . 'assets/js/admin.js', array('jquery'), $this->version, false);
        
        // Enqueue media uploader scripts
        wp_enqueue_media();
    }

    /**
     * Add menu items in the admin area.
     *
     * @since    1.0.0
     */
    public function add_admin_menu() {
        add_menu_page(
            __('Radio Player', 'online-radio-player'),
            __('Radio Player', 'online-radio-player'),
            'manage_options',
            'radio-player',
            array($this, 'display_admin_page'),
            'dashicons-format-audio',
            30
        );
    }

    /**
     * Display the admin page content.
     *
     * @since    1.0.0
     */
    public function display_admin_page() {
        echo '<div class="wrap">';
        echo '<h1>' . __('Online Radio Player Settings', 'online-radio-player') . '</h1>';
        echo '<p>' . __('Manage your radio channels here.', 'online-radio-player') . '</p>';
        echo '<p><a href="' . admin_url('edit.php?post_type=radio_channel') . '" class="button button-primary">' . __('Manage Channels', 'online-radio-player') . '</a></p>';
        
        echo '<h2>' . __('How to Use', 'online-radio-player') . '</h2>';
        echo '<p>' . __('To display a radio player, use the shortcode with the channel ID:', 'online-radio-player') . '</p>';
        echo '<p><code>[online_radio_player channel="ID"]</code></p>';
        echo '<p>' . __('Example:', 'online-radio-player') . ' <code>[online_radio_player channel="123"]</code></p>';
        
        echo '<h3>' . __('Player Skins', 'online-radio-player') . '</h3>';
        echo '<p>' . __('You can choose from 3 different player skins:', 'online-radio-player') . '</p>';
        echo '<div class="radio-skin-examples">';
        echo '<code>[online_radio_player channel="123" skin="default"]</code>';
        echo '<code>[online_radio_player channel="123" skin="modern"]</code>';
        echo '<code>[online_radio_player channel="123" skin="classic"]</code>';
        echo '</div>';
        
        echo '<h3>' . __('Supported Stream Formats', 'online-radio-player') . '</h3>';
        echo '<p>' . __('The player supports various stream formats including:', 'online-radio-player') . '</p>';
        echo '<ul>';
        echo '<li><strong>HTTP/HTTPS Direct:</strong> https://example.com/stream.mp3 (Simple, widely supported)</li>';
        echo '<li><strong>M3U / M3U8:</strong> playlist.m3u / playlist.m3u8 (Playlist file containing one or more streams)</li>';
        echo '<li><strong>PLS:</strong> stream.pls (Common with Shoutcast)</li>';
        echo '<li><strong>XSPF:</strong> playlist.xspf (XML-based playlist)</li>';
        echo '<li><strong>RTSP / RTP:</strong> rtsp://example.com/live (Live streaming, used in apps like VLC)</li>';
        echo '<li><strong>Shoutcast/Icecast:</strong> http://example.com:8000/; (Specialized radio server endpoints)</li>';
        echo '<li><strong>HLS:</strong> https://example.com/stream.m3u8 (Adaptive streaming, iOS compatible)</li>';
        echo '<li><strong>WebRTC / WebSocket:</strong> wss://example.com/live (Low-latency web streaming)</li>';
        echo '</ul>';
        echo '<p class="description">' . __('Note: Some formats like RTSP/RTP and WebRTC may require special handling or external players.', 'online-radio-player') . '</p>';
        
        echo '</div>';
    }

    /**
     * Register the custom post type for radio channels.
     *
     * @since    1.0.0
     */
    public function register_radio_channel_post_type() {
        $labels = array(
            'name'                  => _x('Radio Channels', 'Post type general name', 'online-radio-player'),
            'singular_name'         => _x('Radio Channel', 'Post type singular name', 'online-radio-player'),
            'menu_name'             => _x('Radio Channels', 'Admin Menu text', 'online-radio-player'),
            'name_admin_bar'        => _x('Radio Channel', 'Add New on Toolbar', 'online-radio-player'),
            'add_new'               => __('Add New', 'online-radio-player'),
            'add_new_item'          => __('Add New Channel', 'online-radio-player'),
            'new_item'              => __('New Channel', 'online-radio-player'),
            'edit_item'             => __('Edit Channel', 'online-radio-player'),
            'view_item'             => __('View Channel', 'online-radio-player'),
            'all_items'             => __('All Channels', 'online-radio-player'),
            'search_items'          => __('Search Channels', 'online-radio-player'),
            'parent_item_colon'     => __('Parent Channels:', 'online-radio-player'),
            'not_found'             => __('No channels found.', 'online-radio-player'),
            'not_found_in_trash'    => __('No channels found in Trash.', 'online-radio-player'),
            'featured_image'        => _x('Channel Logo', 'Overrides the "Featured Image" phrase for this post type', 'online-radio-player'),
            'set_featured_image'    => _x('Set logo', 'Overrides the "Set featured image" phrase for this post type', 'online-radio-player'),
            'remove_featured_image' => _x('Remove logo', 'Overrides the "Remove featured image" phrase for this post type', 'online-radio-player'),
            'use_featured_image'    => _x('Use as logo', 'Overrides the "Use as featured image" phrase for this post type', 'online-radio-player'),
            'archives'              => _x('Channel archives', 'The post type archive label used in nav menus', 'online-radio-player'),
            'insert_into_item'      => _x('Insert into channel', 'Overrides the "Insert into post" phrase for this post type', 'online-radio-player'),
            'uploaded_to_this_item' => _x('Uploaded to this channel', 'Overrides the "Uploaded to this post" phrase for this post type', 'online-radio-player'),
            'filter_items_list'     => _x('Filter channels list', 'Screen reader text for the filter links', 'online-radio-player'),
            'items_list_navigation' => _x('Channels list navigation', 'Screen reader text for the pagination', 'online-radio-player'),
            'items_list'            => _x('Channels list', 'Screen reader text for the items list', 'online-radio-player'),
        );

        $args = array(
            'labels'             => $labels,
            'public'             => false,
            'publicly_queryable' => false,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array('slug' => 'radio-channel'),
            'capability_type'    => 'post',
            'has_archive'        => false,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => array('title'),
            'menu_icon'          => 'dashicons-format-audio',
        );

        register_post_type('radio_channel', $args);
    }

    /**
     * Add meta boxes for radio channel custom fields.
     *
     * @since    1.0.0
     */
    public function add_radio_channel_meta_boxes() {
        add_meta_box(
            'radio-channel-stream-url',
            __('Stream URL', 'online-radio-player'),
            array($this, 'render_stream_url_meta_box'),
            'radio_channel',
            'normal',
            'default'
        );

        add_meta_box(
            'radio-channel-logo',
            __('Channel Logo', 'online-radio-player'),
            array($this, 'render_logo_meta_box'),
            'radio_channel',
            'side',
            'default'
        );
        
        add_meta_box(
            'radio-channel-shortcode',
            __('Shortcode', 'online-radio-player'),
            array($this, 'render_shortcode_meta_box'),
            'radio_channel',
            'side',
            'low'
        );
    }

    /**
     * Render the stream URL meta box.
     *
     * @since    1.0.0
     */
    public function render_stream_url_meta_box($post) {
        wp_nonce_field('radio_channel_save_meta_box_data', 'radio_channel_meta_box_nonce');

        $stream_url = get_post_meta($post->ID, '_radio_stream_url', true);

        echo '<label for="radio_stream_url">' . __('Stream URL:', 'online-radio-player') . '</label>';
        echo '<input type="text" id="radio_stream_url" name="radio_stream_url" value="' . esc_attr($stream_url) . '" size="50" placeholder="https://example.com/stream.mp3" />';
        echo '<p class="description">' . __('Enter the stream URL. Supports HTTP/HTTPS, M3U, M3U8, PLS, XSPF, HLS, and more.', 'online-radio-player') . '</p>';
        echo '<p class="description"><strong>' . __('Tip:', 'online-radio-player') . '</strong> ' . __('Test your stream URL in a browser or media player before using it here.', 'online-radio-player') . '</p>';
    }

    /**
     * Render the logo meta box.
     *
     * @since    1.0.0
     */
    public function render_logo_meta_box($post) {
        $logo_id = get_post_meta($post->ID, '_radio_channel_logo', true);
        $logo_url = $logo_id ? wp_get_attachment_url($logo_id) : '';

        echo '<div id="radio-channel-logo-container">';
        if ($logo_url) {
            echo '<img src="' . esc_url($logo_url) . '" alt="' . __('Channel Logo', 'online-radio-player') . '" style="max-width: 100%; height: auto;" />';
        }
        echo '<p>';
        echo '<input type="hidden" id="radio_channel_logo" name="radio_channel_logo" value="' . esc_attr($logo_id) . '" />';
        echo '<button type="button" id="upload_logo_button" class="button">' . __('Upload Logo', 'online-radio-player') . '</button>';
        echo '<button type="button" id="remove_logo_button" class="button" style="margin-left: 10px;' . (!$logo_url ? 'display:none;' : '') . '">' . __('Remove Logo', 'online-radio-player') . '</button>';
        echo '</p>';
        echo '<p class="description">' . __('Recommended size: 200x200 pixels', 'online-radio-player') . '</p>';
        echo '</div>';
    }
    
    /**
     * Render the shortcode meta box.
     *
     * @since    1.0.0
     */
    public function render_shortcode_meta_box($post) {
        $shortcode = '[online_radio_player channel="' . $post->ID . '"]';
        echo '<p>' . __('Use this shortcode to display the player:', 'online-radio-player') . '</p>';
        echo '<input type="text" readonly onclick="this.select()" value="' . esc_attr($shortcode) . '" style="width:100%;" />';
        
        echo '<div class="radio-skin-examples">';
        echo '<p>' . __('With skins:', 'online-radio-player') . '</p>';
        echo '<code>[online_radio_player channel="' . $post->ID . '" skin="modern"]</code>';
        echo '<code>[online_radio_player channel="' . $post->ID . '" skin="classic"]</code>';
        echo '</div>';
        
        echo '<p class="description">' . __('The player automatically detects the stream type and uses the appropriate playback method.', 'online-radio-player') . '</p>';
    }

    /**
     * Save meta box data.
     *
     * @since    1.0.0
     */
    public function save_radio_channel_meta_box_data($post_id) {
        // Check if our nonce is set.
        if (!isset($_POST['radio_channel_meta_box_nonce'])) {
            return;
        }

        // Verify that the nonce is valid.
        if (!wp_verify_nonce($_POST['radio_channel_meta_box_nonce'], 'radio_channel_save_meta_box_data')) {
            return;
        }

        // If this is an autosave, our form has not been submitted, so we don't want to do anything.
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }

        // Check the user's permissions.
        if (isset($_POST['post_type']) && 'radio_channel' == $_POST['post_type']) {
            if (!current_user_can('edit_post', $post_id)) {
                return;
            }
        }

        // Sanitize user input.
        if (isset($_POST['radio_stream_url'])) {
            $stream_url = sanitize_text_field($_POST['radio_stream_url']);
            update_post_meta($post_id, '_radio_stream_url', $stream_url);
        }

        if (isset($_POST['radio_channel_logo'])) {
            $logo_id = sanitize_text_field($_POST['radio_channel_logo']);
            update_post_meta($post_id, '_radio_channel_logo', $logo_id);
        }
    }
}