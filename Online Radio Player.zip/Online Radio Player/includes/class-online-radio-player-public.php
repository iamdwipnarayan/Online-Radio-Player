<?php

/**
 * The public-facing functionality of the plugin.
 */

class Online_Radio_Player_Public {

    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * Initialize the class and set its properties.
     *
     * @since    1.0.0
     * @param      string    $plugin_name       The name of the plugin.
     * @param      string    $version    The version of this plugin.
     */
    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_styles() {
        wp_enqueue_style($this->plugin_name, ONLINE_RADIO_PLAYER_URL . 'assets/css/public.css', array(), $this->version, 'all');
    }

    /**
     * Register the JavaScript for the public-facing side of the site.
     *
     * @since    1.0.0
     */
    public function enqueue_scripts() {
        // Enqueue hls.js for HLS streaming support
        wp_enqueue_script('hls-js', 'https://cdn.jsdelivr.net/npm/hls.js@1.1.5/dist/hls.min.js', array(), '1.1.5', true);
        
        // Enqueue our custom script
        wp_enqueue_script($this->plugin_name, ONLINE_RADIO_PLAYER_URL . 'assets/js/public.js', array('jquery'), $this->version, true);
    }
}