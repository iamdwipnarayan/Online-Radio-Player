<?php

/**
 * The shortcode functionality of the plugin.
 */

class Online_Radio_Player_Shortcode {

    /**
     * Initialize the shortcode
     *
     * @since    1.0.0
     */
    public function __construct() {
        add_shortcode('online_radio_player', array($this, 'render_radio_player'));
    }

    /**
     * Render the radio player shortcode
     *
     * @since    1.0.0
     * @param    array    $atts       Shortcode attributes
     * @return   string              The HTML output of the player
     */
    public function render_radio_player($atts) {
        // Parse shortcode attributes
        $atts = shortcode_atts(array(
            'channel' => '',
            'skin' => 'default' // default, modern, classic
        ), $atts, 'online_radio_player');

        // Validate channel ID
        if (empty($atts['channel'])) {
            return '<p>' . __('Please specify a radio channel ID.', 'online-radio-player') . '</p>';
        }

        // Get specific radio channel
        $args = array(
            'post_type' => 'radio_channel',
            'p' => (int) $atts['channel'],
            'post_status' => 'publish'
        );

        $channels_query = new WP_Query($args);

        if (!$channels_query->have_posts()) {
            return '<p>' . __('Radio channel not found.', 'online-radio-player') . '</p>';
        }

        // Get the channel
        $channels_query->the_post();
        
        // Get channel data
        $stream_url = get_post_meta(get_the_ID(), '_radio_stream_url', true);
        $logo_id = get_post_meta(get_the_ID(), '_radio_channel_logo', true);
        $logo_url = $logo_id ? wp_get_attachment_url($logo_id) : '';
        
        // Validate stream URL
        if (empty($stream_url)) {
            wp_reset_postdata();
            return '<p>' . __('Stream URL not set for this channel.', 'online-radio-player') . '</p>';
        }
        
        // Sanitize skin option
        $skin = in_array($atts['skin'], array('default', 'modern', 'classic')) ? $atts['skin'] : 'default';
        
        // Determine MIME type and player type based on URL
        $stream_info = $this->get_stream_info($stream_url);
        $mime_type = $stream_info['mime_type'];
        $player_type = $stream_info['player_type'];
        
        // Start output buffering
        ob_start();

        echo '<div class="online-radio-player online-radio-player--' . esc_attr($skin) . '" data-channel-id="' . esc_attr(get_the_ID()) . '" data-player-type="' . esc_attr($player_type) . '">';
        
        // Player controls
        echo '<div class="radio-player-controls">';
        echo '<div class="radio-channel-info">';
        if ($logo_url) {
            echo '<img src="' . esc_url($logo_url) . '" alt="' . esc_attr(get_the_title()) . '" class="radio-channel-logo" />';
        }
        echo '<div class="radio-channel-details">';
        echo '<span class="radio-channel-title">' . esc_html(get_the_title()) . '</span>';
        echo '<span class="radio-live-badge">LIVE</span>';
        echo '</div>';
        echo '</div>';
        
        echo '<div class="radio-player-main-controls">';
        echo '<button id="play-pause-button-' . esc_attr(get_the_ID()) . '" class="radio-control-button play-pause-button" data-channel="' . esc_attr(get_the_ID()) . '">';
        echo '<span class="play-icon">&#9658;</span>';
        echo '<span class="pause-icon" style="display:none;">&#10074;&#10074;</span>';
        echo '</button>';
        
        echo '<div class="radio-volume-controls">';
        echo '<button id="mute-button-' . esc_attr(get_the_ID()) . '" class="radio-control-button mute-button" data-channel="' . esc_attr(get_the_ID()) . '">';
        echo '<span class="volume-icon">&#128266;</span>';
        echo '<span class="mute-icon" style="display:none;">&#128263;</span>';
        echo '</button>';
        echo '<input type="range" id="volume-slider-' . esc_attr(get_the_ID()) . '" class="volume-slider" min="0" max="1" step="0.01" value="1" data-channel="' . esc_attr(get_the_ID()) . '" />';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        
        // Hidden audio element with proper attributes for streaming
        if ($player_type === 'hls') {
            // For HLS, we'll handle it with JavaScript
            echo '<video id="radio-hls-player-' . esc_attr(get_the_ID()) . '" class="radio-hls-player" preload="none" data-channel="' . esc_attr(get_the_ID()) . '" data-stream-url="' . esc_url($stream_url) . '" style="display:none;"></video>';
            echo '<audio id="radio-audio-player-' . esc_attr(get_the_ID()) . '" class="radio-audio-player" preload="none" data-channel="' . esc_attr(get_the_ID()) . '" style="display:none;"></audio>';
        } else {
            // For all other types, use audio element
            echo '<audio id="radio-audio-player-' . esc_attr(get_the_ID()) . '" class="radio-audio-player" preload="none" data-channel="' . esc_attr(get_the_ID()) . '" crossorigin="anonymous" playsinline>';
            echo '<source src="' . esc_url($stream_url) . '" type="' . esc_attr($mime_type) . '">';
            echo 'Your browser does not support the audio element.';
            echo '</audio>';
        }
        
        echo '</div>';

        // Reset post data
        wp_reset_postdata();

        // Return the buffered content
        return ob_get_clean();
    }
    
    /**
     * Determine stream information based on URL
     *
     * @param string $url Stream URL
     * @return array Stream information including MIME type and player type
     */
    private function get_stream_info($url) {
        $info = array(
            'mime_type' => 'audio/mpeg',
            'player_type' => 'audio'
        );
        
        // Convert to lowercase for easier matching
        $url_lower = strtolower($url);
        
        // Check for specific stream types
        if (strpos($url_lower, '.m3u8') !== false) {
            $info['mime_type'] = 'application/x-mpegURL';
            $info['player_type'] = 'hls';
        } elseif (strpos($url_lower, '.m3u') !== false) {
            $info['mime_type'] = 'audio/x-mpegurl';
            $info['player_type'] = 'audio';
        } elseif (strpos($url_lower, '.pls') !== false) {
            $info['mime_type'] = 'audio/x-scpls';
            $info['player_type'] = 'audio';
        } elseif (strpos($url_lower, '.xspf') !== false) {
            $info['mime_type'] = 'application/xspf+xml';
            $info['player_type'] = 'audio';
        } elseif (strpos($url_lower, 'rtsp://') === 0 || strpos($url_lower, 'rtp://') === 0) {
            $info['mime_type'] = 'application/x-rtsp';
            $info['player_type'] = 'external'; // Requires external player
        } elseif (strpos($url_lower, 'wss://') === 0 || strpos($url_lower, 'ws://') === 0) {
            $info['mime_type'] = 'audio/webm';
            $info['player_type'] = 'webrtc';
        } elseif (strpos($url_lower, '.aac') !== false) {
            $info['mime_type'] = 'audio/aac';
            $info['player_type'] = 'audio';
        } elseif (strpos($url_lower, '.ogg') !== false || strpos($url_lower, '.oga') !== false) {
            $info['mime_type'] = 'audio/ogg';
            $info['player_type'] = 'audio';
        } elseif (strpos($url_lower, '.wav') !== false) {
            $info['mime_type'] = 'audio/wav';
            $info['player_type'] = 'audio';
        } elseif (strpos($url_lower, '.flac') !== false) {
            $info['mime_type'] = 'audio/flac';
            $info['player_type'] = 'audio';
        } else {
            // Default to mp3 for most radio streams
            $info['mime_type'] = 'audio/mpeg';
            $info['player_type'] = 'audio';
        }
        
        return $info;
    }
}